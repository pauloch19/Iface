/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iface;
import java.util.Scanner;


/**
 *
 * @author paulc
 */
public class Friends {
    java.util.ArrayList<Users> friends = new java.util.ArrayList<>();
    java.util.ArrayList<Users> sent_by = new java.util.ArrayList<>();
    
    public void AddFriend(Users user)
    {
        friends.add(user);
    }
    
    public void WhoSent(Users user)
    {
       sent_by.add(user);
    }
    
    public void CheckFriendshipInvite(Users user_now)
    {
        int i;
        Users user;
        Scanner scanner = new Scanner(System.in);
        for(i=0;i<sent_by.size();i++)
        {
            user = sent_by.get(i);
            System.out.println(user.getNickname()+" enviou convite de amizade. Deseja aceitar?");
            System.out.println("sim\nnao\nagora nao");
            String option = scanner.nextLine();
            if(option.equals("sim"))
            {
                friends.add(user);
                user.friends_list.friends.add(user_now);
                System.out.println("Agora você é amigo de "+user.getNickname()+".");
                sent_by.remove(user);
            }
            else if(option.equals("nao"))
            {
                sent_by.remove(user);
                System.out.println("Você recusou o convite.");
            }
            else if(option.equals("agora nao"))
            {
                System.out.println("O convite ficará pendente.");
            }
            
        }
    }
    
    public void SeeFriends()
    {
        int i;
        Users user;
        Scanner scanner = new Scanner(System.in);
        for(i=0;i<friends.size();i++)
        {
            user = friends.get(i);
            System.out.println(user.getNickname());
        }
    }
    
    public int CheckFriendList(String name)
    {
        int i, checker=0;
        Users user;
        for(i=0;i<friends.size();i++)
        {
            user = friends.get(i);
            if(user.getNickname().equals(name))
            {
                checker=1;
            }
        }
        
        return checker;
    }
    
    public void RemoveFriend(Users user)
    {
        int i;
        Users friend;
        for(i=0;i<friends.size();i++)
        {
            friend = friends.get(i);
            if(friend.getLogin().equals(user.getLogin()))
            {
                friends.remove(friend);
                break;
            }
        }
    }
    
    
}
