/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iface;
import java.util.Scanner;

/**
 *
 * @author paulc
 */
public class Sys {
    java.util.ArrayList<Users> system = new java.util.ArrayList<>();
    java.util.ArrayList<Communities> communities = new java.util.ArrayList<>();

    public int SearchEqualsLogins(String login)
    {
        int i, checker=0;
        Users user = new Users();
        for(i=0;i<system.size();i++)
        {
            user = system.get(i);
            if(user.getLogin().equals(login))
            {
                checker=1;
                break;
            }   
        }
        return checker;
    }
    
     public int SearchEqualsNicks(String nickname)
    {
        int i, checker=0;
        Users user = new Users();
        for(i=0;i<system.size();i++)
        {
            user = system.get(i);
            if(user.getNickname().equals(nickname))
            {
                checker=1;
                break;
            }   
        }
        return checker;
    }
     
     
     public Users VerifyUser(String login, String password)
     {
         int i, checker=0;
         Users user = new Users();
         for(i=0;i<system.size();i++)
         {
            user = system.get(i);
            if(user.getLogin().equals(login) && user.getPassword().equals(password))
            {
                break;
            }  
         }
         return user;
     }
     
     public void Adition(Users user)
     {
       system.add(user);
     }
     
     public Users SearchUser(String name)
     {
         int i, checker=0;
         Users user = new Users();
         Users user2 = new Users();
         for(i=0;i<system.size();i++)
         {
             user = system.get(i);
             if(user!=null && user.getNickname().equals(name))
             {  
                 user2 = user;
                 break;
             } 
            
         }  
         return user2;
     }
     
     public void SearchUserBySecurity(String phrase)
     {
         int i;
         Users user = new Users();
         Scanner scanner = new Scanner(System.in);
         for(i=0;i<system.size();i++)
         {
             user = system.get(i);
             if(user!=null && user.getSecurity_phrase().equals(phrase))
             {  
               System.out.println("Seu login é "+user.getLogin()+".");
               System.out.println("Você confirma essa informação");
               String option = scanner.nextLine();
               if(option.equals("sim"))
               {
                   System.out.println("Sua senha é "+user.getPassword()+".");
                   break;
               }
             } 
         }  
     }
     
     
     public void ProfileView(Users user)
     {
        //System.out.println("Por favor, confirme a identidade do usuário que você deseja adicionar.");
        System.out.printf("Nome do usuário: %s\n", user.getNickname());
        System.out.printf("Idade: %d\n", user.getAge());
        System.out.printf("Data de nascimento: %d/%d/%d\n", user.getBirthday_day(), user.getBirthday_month(), user.getBirthday_year());
        System.out.printf("Mora no %s no estado de %s, na cidade %s\n", user.getCountry(), user.getState(), user.getCity());
        System.out.printf("Estado de relacionamento: %s\n", user.getRelationship());     
     }
          
     public void RemoveUser(Users user)
     {
        int i;
        Users user2;
        for(i=0;i<system.size();i++) 
        {
           user2 = system.get(i);
           user2.friends_list.RemoveFriend(user);
        }
        system.remove(user);
        
        System.out.println("Usuário removido com sucesso, não existe mais nenhuma informação disponível sobre esse usuário no sistema do Iface");
     }
     
     public void RemoveCommunities(Users user)
     {
         int i;
        Communities community;
        for(i=0;i<communities.size();i++) 
        {
           community = communities.get(i);
           if(community.getIdentification_owner().equals(user.getLogin()))
           {
               communities.remove(community);
           }
        }
         
     }
     
     public void AddCommunity(Communities community)
     {
         
         communities.add(community);
     }
     
     public void SeeAllCommunity()
     {
         int i;
         Communities community;
         for(i=0;i<communities.size();i++)
         {
             community = communities.get(i);
             System.out.println("Nome da comunidade: "+community.getCommunity_name()+" e o dono da comunidade é "+community.getOwner()+".");
             System.out.println("Descrição da comunidade: "+community.getDescription()+".");
             System.out.println("Membros: ");
             community.SeeMembers();
         }
     }
     
    public void SendRequest(String name, Users member)
    {
        int i;
        Communities community;
        Users user;
        for(i=0;i<communities.size();i++)
        {
            community = communities.get(i);
            if(community.getCommunity_name().equals(name))
            {
                if(member.getLogin().equals(community.getIdentification_owner()))
                {
                    System.out.println("Você não pode participar dessa comunidade pois já é o dono");
                }
                else
                {
                      community.AddRequest(member);
                }
                break;
            }    
        }
    }
    
    public void SendMessage(String name, Users user)
    {
        int i;
        Communities community;
        Message message = new Message();
        Scanner scanner = new Scanner(System.in);
        for(i=0;i<communities.size();i++)
        {
            community = communities.get(i);
            if(community.getCommunity_name().equals(name))
            {
               System.out.println("Qual mensagem você enviará para comunidade?");
               String text = scanner.nextLine();
               community.messages.add(text);
               community.sent_by.add(user.getNickname());
            }    
        }  
    }
    
    public void SeeMyCommunities(Users user)
    {
        int i;
        Scanner scanner = new Scanner(System.in);
        Communities community = new Communities();
        for(i=0;i<communities.size();i++)
        {
            community = communities.get(i);
            if(community.getIdentification_owner().equals(user.getLogin()))
            {
                System.out.println("A comunidade "+community.getCommunity_name()+" é sua.");
                System.out.println("Digite:\n1.Para ver os membros\n2.Para aceitar novos membros\n3.Para remover membros");
                int option = scanner.nextInt();
                scanner.nextLine();
                if(option==1)
                {
                    community.SeeMembersAdmin();
                }
                if(option==2)
                {
                    community.SeeRequests();
                }
                if(option==3)
                {
                   community.SeeMembersAdmin();
                   System.out.println("Digite o login do membro que você deseja remover: ");
                   String login = scanner.nextLine();
                   community.RemoveMember(login);
                           
                }
            }
        }
    }
    
    public void MyMembership(Users user)
    {
        int i;
        Communities community;
        for(i=0;i<communities.size();i++)
        {
            community = communities.get(i);
            System.out.println(community.getCommunity_name());
        } 
    }
       
    
    
     public void SeeCommunityLikeMember(String name)
     {
         int i;
         Communities community;
         for(i=0;i<communities.size();i++)
         {
             community = communities.get(i);
             if(community.getCommunity_name().equals(name))
             {
                System.out.println("Nome da comunidade: "+community.getCommunity_name()+" e o dono da comunidade é"+community.getOwner()+".");
                System.out.println("Descrição da comunidade: "+community.getDescription()+".");
                System.out.println("Mensagens:");
                community.SeeMessages();
                System.out.println("Membros: ");
                community.SeeMembers();
                break;
             }
         }
     }
}
