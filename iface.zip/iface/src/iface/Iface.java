package iface;
import java.util.Scanner;

/**
 *
 * @author paulc
 */
public class Iface {

   
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Sys system = new Sys();
        Communities communities = new Communities();
        int checker, choice;
        String login;
        String password;
        String option;
        String nickname;
        String user_friend;
        System.out.println("                            Iface                 ");
        System.out.println("Bem-vindo a rede social Iface, as ações disponiveis serão apresentadas abaixo: ");
        System.out.println("A qualquer momento digite sair para sair do sistema ou continuar para continuar no sistema.");
        option = scanner.nextLine();
        while(option.equals("continuar"))
        {
            System.out.println("Já tem uma conta?");
            option = scanner.nextLine();
            if(option.equals("sim"))
            {
                System.out.println("Deseja fazer login ou Deseja recuperar sua conta?");
                option = scanner.nextLine();
                if(option.equals("login"))
                {
                    Users user;
                    System.out.print("Digite seu login: ");
                    login = scanner.nextLine();
                    System.out.print("Digite sua senha: ");
                    password = scanner.nextLine();
                    user = system.VerifyUser(login, password);
                    if(user.getLogin().equals(login) && user.getPassword().equals(password))
                    {
                        System.out.println("Login efetuado com sucesso!");
                        System.out.println("Digite: ");
                        System.out.println("1.Criar Perfil\n2.Editar Perfil\n3.Adicionar Amigos\n4.Enviar Mensagem\n5.Entrar ou Criar comunidade");
                        System.out.println("6.Deletar Conta\n7.Sair");
                        choice = scanner.nextInt();
                        scanner.nextLine();
                        while(choice!=7)
                        {
                           if(choice==1)
                           {
                               if(user.getProfile()==1)
                               {
                                  System.out.println("Perfil já foi criado.");
                               }
                               else
                               {
                                     user.ProfileCreation(user);
                               }
                           }
                           if(choice==2)
                           {
                               if(user.getProfile()==1)
                               {
                                   user.ProfileEdition(user);
                               }
                           }
                           if(choice==3)
                           {
                               Users friend;
                               System.out.println("Você entrou na opção Adicionar Amigos. Para continuar digite: ");
                               System.out.println("adicionar: para adicionar amigos");
                               System.out.println("verificar: para verificar solicitações de amizade");
                               System.out.println("ver: para ver lista de amigos");
                               option = scanner.nextLine();
                               if(option.equals("adicionar") && user.getProfile()==1)
                               {
                                   System.out.print("Qual nome do usuário que você deseja adicionar: ");
                                   user_friend = scanner.nextLine();
                                   if(user.friends_list.CheckFriendList(user_friend)==0)
                                   {
                                        friend = system.SearchUser(user_friend);
                                        system.ProfileView(friend);
                                        System.out.println("Esse é o usuário que você deseja adicionar?(sim ou nao)");
                                        option = scanner.nextLine();
                                        if(option.equals("sim"))
                                        {
                                            friend.friends_list.WhoSent(user);
                                            System.out.println("Convite Enviado com sucesso");
                                        }
                                   }
                                   else
                                   {
                                       System.out.println("Você já tem esse usuário como amigo!");
                                   }
                               }
                               else if(user.getProfile()==0)
                               {
                                   System.out.println("Por favor, crie um perfil.");
                               }
                               else if(option.equals("verificar"))
                               {
                                   user.friends_list.CheckFriendshipInvite(user);
                               }
                               else if(option.equals("ver"))
                               {
                                   user.friends_list.SeeFriends();
                               }   
                           }
                           if(choice==4)
                           {
                               Users friend;
                               System.out.println("Você entrou no Bate-papo.");
                               System.out.println("Selecione um usuário do Iface.");
                               String friend_name = scanner.nextLine();
                               friend = system.SearchUser(friend_name);
                               if(friend.getNickname()==null)
                               {
                                    System.out.println("Usuário não encontrado.");
                               }
                               else
                               {
                                    if(friend.getLogin().equals(user.getLogin()))
                                    {
                                        System.out.println("Você não pode mandar mensagem para si mesmo.");
                                    }
                                    else
                                    {
                                        system.ProfileView(friend);
                                        System.out.println("Você entrará na sala de conversa com o usuário "+friend.getNickname()+".");
                                        System.out.println("Digite enviar para mandar uma mensagem ou entrar para ver as mensagens recebidas.");
                                        option = scanner.nextLine();
                                        if(option.equals("enviar"))
                                        {
                                            System.out.print("Escreva uma mensagem ou digite sair: ");
                                            String message_text = scanner.nextLine();
                                            while(!message_text.equals("sair"))
                                            {
                                                friend.SearchSender(user, message_text);
                                                System.out.println("Mensagem enviada com sucesso!");
                                                System.out.print("Escreva uma mensagem ou digite sair: ");
                                                message_text = scanner.nextLine();
                                            }
                                        }
                                        if(option.equals("entrar"))
                                        {
                                            user.SeeMessages(friend);
                                        }
                                    }
                                    
                                }
                           }
                           if(choice==5)
                           {
                               System.out.println("Você entrou na opção Comunidade.");
                               System.out.println("Escolha uma das opções abaixo: ");
                               System.out.println("criar: Você criará uma comunidade");
                               System.out.println("gerenciar: Você poderá aceitar novos membros ou remover algum membro");
                               System.out.println("participar: Você enviará a solicitação de entrada ao dono da comunidade");
                               System.out.println("ver: Você verá as comunidades das quais é membro.");
                               System.out.println("enviar: você enviará mensagem para uma comunidade da qual faz parte.");
                               System.out.println("entrar: você entrará em uma comunidade da qual faz parte");
                               option = scanner.nextLine();
                               if(option.equals("criar"))
                               {
                                   Communities community = new Communities();
                                   community.CreatingNewCommunity(user);
                                   system.AddCommunity(community);
                                   community.members.add(user);
                               }
                               if(option.equals("participar"))
                               {
                                   system.SeeAllCommunity();
                                   System.out.println("Digite o nome de uma das comunidades citadas acima: ");
                                   option = scanner.nextLine();
                                   system.SendRequest(option, user);
                                   System.out.println("Solicitação enviada!");
                               }
                               if(option.equals("gerenciar"))
                               {
                                   system.SeeMyCommunities(user);
                               }
                               if(option.equals("ver"))
                               {
                                   System.out.println("Comunidades das quais você faz parte:");
                                   system.MyMembership(user);
                               }
                               if(option.equals("enviar"))
                               {
                                   system.MyMembership(user);
                                   System.out.print("Escolha uma comunidade acima: ");
                                   option = scanner.nextLine();
                                   system.SendMessage(option, user);
                               }
                               if(option.equals("entrar"))
                               {
                                   system.MyMembership(user);
                                   System.out.print("Escolha uma comunidade acima: ");
                                   option = scanner.nextLine();
                                   system.SeeCommunityLikeMember(option);
                               }
                               
                               
                           }
                           if(choice==6)
                           {
                               System.out.println("Tem Certeza que deseja remover sua conta?(sim ou nao)");
                               option = scanner.nextLine();
                               if(option.equals("sim"))
                               {
                                   system.RemoveCommunities(user);
                                   system.RemoveUser(user);
                                   break;
                               }
                           }
                           System.out.print("Escolha outra opção: ");
                           choice = scanner.nextInt();
                           scanner.nextLine();
                        }   
                    }
                    else
                    {
                        System.out.println("Não há usuário registrado com esse login e senha.");
                    }
                   
                }
                else if(option.equals("nao"))
                {
                    System.out.println("Você voltará ao menu principal");
                }
                else if(option.equals("recuperar"))
                {
                    System.out.println("Você entrou na opção de recuperar conta");
                    System.out.println("Para fazer isso, digite a frase de segurança: ");
                    String security = scanner.nextLine();
                    system.SearchUserBySecurity(security);
                    
                }
            }
            else
            {
                System.out.println("Deseja criar uma conta?");
                option = scanner.nextLine();
                if(option.equals("sim"))
                {
                    Users user = new Users();
                    System.out.println("Qual login você deseja usar para acessar sua conta?");
                    login = scanner.nextLine();
                    checker = system.SearchEqualsLogins(login);
                    while(checker!=0)
                    {
                        checker = system.SearchEqualsLogins(login);
                        if(checker==1)
                        {
                            System.out.println("Esse login já existe, digite outro, por favor:");
                            login = scanner.nextLine();
                        }
                    }
                    user.setLogin(login); 
                    System.out.println("Qual sua senha: ");
                    password = scanner.nextLine();
                    user.setPassword(password); 
                    system.Adition(user);
                } 
            }
            System.out.println("digite sair para sair do sistema ou continuar para continuar no sistema.");
            option = scanner.nextLine();
        }
       // system.AllUsers();          
    }    

}