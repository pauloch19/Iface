package iface;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author paulc
 */
public class Users {
    
    private String login;
    private String password;
    private String nickname;
    private String city;
    private String state;
    private String country;
    private String relationship;
    private String security_phrase;
    private int birthday_day;
    private int birthday_month;
    private int birthday_year;
    private int age;
    private int profile;
    Friends friends_list = new Friends();
    java.util.ArrayList<Message> my_messages = new java.util.ArrayList<>();
    
    public String getSecurity_phrase() {
        return security_phrase;
    }

    public void setSecurity_phrase(String security_phrase) {
        this.security_phrase = security_phrase;
    }
    
    public int getProfile() {
        return profile;
    }

    public void setProfile(int profile) {
        this.profile = profile;
    }

    public int getBirthday_day() {
        return birthday_day;
    }

    public void setBirthday_day(int birthday_day) {
        this.birthday_day = birthday_day;
    }

    public int getBirthday_month() {
        return birthday_month;
    }

    public void setBirthday_month(int birthday_month) {
        this.birthday_month = birthday_month;
    }

    public int getBirthday_year() {
        return birthday_year;
    }

    public void setBirthday_year(int birthday_year) {
        this.birthday_year = birthday_year;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

  
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }
    
    
    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }
   
    public void ProfileCreation(Users user)
    {
        Scanner scanner = new Scanner(System.in);
        String nick = new String();
        System.out.print("Para ser identificado por outros usuários no Iface, você precisará de um nome. ");
        System.out.println("Esse nome ficará visível para qualquer outro usuário.");
        System.out.println("Qual será seu nome público: ");
        nick = scanner.nextLine();
        user.setNickname(nick);
        System.out.print("Digite sua data de nascimento.\n");
        System.out.print("Dia: ");
        int day = scanner.nextInt();
        user.setBirthday_day(day);
        System.out.print("Mês: ");
        int month = scanner.nextInt();
        user.setBirthday_month(month);
        System.out.print("Ano: ");
        int year = scanner.nextInt();
        user.setBirthday_year(year);
        System.out.print("Qual sua idade: ");
        int ag = scanner.nextInt();
        user.setAge(ag);
        scanner.nextLine();
        System.out.print("Informe o país onde mora: ");
        String ctr = scanner.nextLine();
        user.setCountry(ctr);
        System.out.print("Informe o estado em que reside: ");
        String stt = scanner.nextLine();
        user.setState(stt);
        System.out.print("Informe a cidade em que reside: ");
        String ct = scanner.nextLine();
        user.setCity(ct);
        System.out.print("Qual seu estado de relacionamento: ");
        String relation = scanner.nextLine();
        user.setRelationship(relation);
        System.out.print("Informe uma frase ou palavra de segurança: ");
        String phrase =  scanner.nextLine();
        user.setSecurity_phrase(phrase);
        user.setProfile(1);   
    }
    
    public void ProfileEdition(Users user)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Você entrou na opção editar perfil, deseja continuar nessa opção?");
        System.out.println("Responda sim ou nao");
        String option = scanner.nextLine(); 
        if(option.equals("sim"))
        {
            System.out.println("Deseja alterar seu nome público?(sim ou nao)");
            option = scanner.nextLine();
            if(option.equals("sim"))
            {
                String nick = scanner.nextLine();
                user.setNickname(nick);
            }
            System.out.println("Deseja alterar sua data de nascimento?(sim ou nao)");
            option = scanner.nextLine();
            if(option.equals("sim"))
            {
               System.out.print("Dia: ");
               int day = scanner.nextInt();
               user.setBirthday_day(day);
               System.out.print("Mês: ");
               int mth = scanner.nextInt();
               user.setBirthday_month(mth);
               System.out.print("Ano: ");
               int yr = scanner.nextInt();
               user.setBirthday_year(yr);
               scanner.nextLine();
            }
            System.out.println("Deseja alterar sua idade?(sim ou nao)");
            option = scanner.nextLine();
            if(option.equals("sim"))
            {
                System.out.print("Insira sua nova idade: ");
                int ag = scanner.nextInt();
                user.setAge(ag);
            }
            System.out.println("Deseja alterar o país onde você reside?(sim ou nao)");
            option = scanner.nextLine();
            if(option.equals("sim"))
            {
                System.out.print("Qual o novo país: ");
                String ctr = scanner.nextLine();
                user.setCountry(ctr);
            }
            System.out.println("Deseja alterar o estado onde você reside?(sim ou nao)");
            option = scanner.nextLine();
            if(option.equals("sim"))
            {
                System.out.print("Qual o novo estado: ");
                String stt = scanner.nextLine();
                user.setState(stt);
            }
            System.out.println("Deseja alterar a ciade onde você reside?(sim ou nao)");
            option = scanner.nextLine();
            if(option.equals("sim"))
            {
                System.out.print("Qual a nova cidade: ");
                String ct = scanner.nextLine();
                user.setCity(ct);
            }
            System.out.println("Deseja alterar seu estado de relacionamento?(sim ou nao)");
            option = scanner.nextLine();
            if(option.equals("sim"))
            {
                System.out.print("Informe seu novo estado de relacionamneto: ");
                String relation = scanner.nextLine();
                user.setRelationship(relation);
            }
            System.out.println("Deseja alterar a sua frase de segurança?(sim ou nao)");
            option = scanner.nextLine();
            if(option.equals("sim"))
            {
                System.out.print("Nova frase: ");
                String phrase = scanner.nextLine();
                user.setSecurity_phrase(phrase);
            }
        } 
    }   
    
    public void SearchSender(Users user, String text)
    {
        int i, checker=0;
        Message message;
        for(i=0;i<my_messages.size();i++)
        {
            message = my_messages.get(i);
            if(message.getSender().equals(user.getLogin()))
            {
                message.AddMessage(text);
                checker=1;
            }
        }
        if(checker==0)
        {
            Message new_message = new Message();
            new_message.setSender(user.getLogin());
            new_message.AddMessage(text);
            my_messages.add(new_message);
        }
        
        
        
        
    }
    public void SeeMessages(Users user)
    {
        int i;
        Message message;
        for(i=0;i<my_messages.size();i++)
        {
            message = my_messages.get(i);
            if(user.getLogin().equals(message.getSender()))
            {
               message.SeeM(user);
               break;
            }
        }
    }
    
 
    
    
}
