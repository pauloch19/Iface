/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iface;
import java.util.Scanner;
/**
 *
 * @author paulc
 */
public class Communities {
    private String owner;
    private String identification_owner;
    private String description;
    private String community_name;
    java.util.ArrayList<Users>  members = new java.util.ArrayList<>();
    java.util.ArrayList<Users>  request = new java.util.ArrayList<>();
  //  java.util.ArrayList<Message> messages_c = new java.util.ArrayList<>();
    java.util.ArrayList<String> messages = new java.util.ArrayList<>();
    java.util.ArrayList<String> sent_by = new java.util.ArrayList<>();
    public String getIdentification_owner() {
        return identification_owner;
    }

    public void setIdentification_owner(String identification_owner) {
        this.identification_owner = identification_owner;
    }
    
    
    public String getOwner() {
        return owner;
    }

    public void setOwner(String Owner) {
        this.owner = Owner;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String Description) {
        this.description = Description;
    }

    public String getCommunity_name() {
        return community_name;
    }

    public void setCommunity_name(String community_name) {
        this.community_name = community_name;
    }
    
    public void CreatingNewCommunity(Users user)
    {
        Scanner scanner = new Scanner(System.in);
        setOwner(user.getNickname());
        setIdentification_owner(user.getLogin());
        System.out.println("Qual o nome da sua comunidade: ");
        String name = scanner.nextLine();
        setCommunity_name(name);
        System.out.println("A sua comunidade precisará de uma descrição: ");
        String descript = scanner.nextLine();
        setDescription(descript);
        System.out.println("A comunidade "+getCommunity_name()+" foi criada com sucesso!");
    }
    
    public void AddRequest(Users member)
    {
        request.add(member);
    }
    
    public void SeeMembersAdmin()
    {
        Users member;
        int i;
        for(i=0;i<members.size();i++)
        {
            member = members.get(i);
            System.out.println("Nome:"+member.getNickname()+"\nLogin:"+member.getLogin());
        }
    }
    
    public void SeeMembers()
    {
        Users member;
        int i;
        for(i=0;i<members.size();i++)
        {
            member = members.get(i);
            System.out.println(member.getNickname());
        }
    }
    
    public void Membership(Users user, Communities community)
    {
        Users member;
        int i, checker=0;
        for(i=0;i<members.size();i++)
        {
           member = members.get(i);
           if(member.getLogin().equals(user.getLogin()))
           {
              System.out.println(community.getCommunity_name());
               break;
           }
        }
      
    }
    
    public void SeeRequests()
    {
        int i;
        Users member;
        Scanner scanner = new Scanner(System.in);
        for(i=0;i<request.size();i++)
        {
            member = request.get(i);
            System.out.println("O usuário "+member.getNickname()+" deseja participar da sua comundiade.");
            System.out.println("Para aceitar, digite aceitar.");
            System.out.println("Para recusar, digite recusar.");
            System.out.println("Para aceitar depois, digite passar");
            String option = scanner.nextLine();
            if(option.equals("aceitar"))
            {
                members.add(member);
                request.remove(request.get(i));
                System.out.println("O usuário "+member.getNickname()+" faz parte da comunidade");
            }
            else
            {
                request.remove(request.get(i));
                System.out.println("O usuário "+member.getNickname()+" não faz parte da comunidade");
            }
        }
        
      
    }
    
    public void RemoveMember(String login)
    {
        int i;
        Users member;
        Scanner scanner = new Scanner(System.in);
        for(i=0;i<members.size();i++)
        {
            member = members.get(i);
            if(member.getLogin().equals(login))
            {
                System.out.println("Tem certeza que deseja remover o usuário "+member.getNickname()+" de login "+member.getLogin()+"da sua comunidade");
                System.out.println("Digite sim ou nao: ");
                String option = scanner.nextLine();
                if(option.equals("sim"))
                {
                    members.remove(member);
                }
            }
        }
    }
    
    public void SeeMessages()
    {
        int i;
        String text;
        String sent;
        for(i=0;i<messages.size();i++)
        {
            text = messages.get(i);
            sent = sent_by.get(i);
           System.out.println(sent+": "+text);
        }
        
    }

}
