package iface;

/**
 *
 * @author paulc
 */
public class Message {
    private String sender;
    java.util.ArrayList<String> messages = new java.util.ArrayList<>();
    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public void AddMessage(String message)
    {
        messages.add(message);
    }
    
    public void SeeM(Users user)
    {
        int i;
        String m;
        for(i=0;i<messages.size();i++)
        {
            m = messages.get(i);
            System.out.println(user.getNickname()+": "+m);
        }
    }
}
